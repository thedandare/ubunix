output "public_ip" {
  value = aws_instance.nixos_x86_64.public_ip
}

output "ssh_root_2409" {
  value = "ssh -p ${var.ssh_port} root@${aws_instance.nixos_x86_64.public_ip}"
}

output "ssh_nixos_2409" {
  value = "ssh -p ${var.ssh_port} nixos@${aws_instance.nixos_x86_64.public_ip}"
}

output "ssh_root_22_debug" {
  value = "ssh root@${aws_instance.nixos_x86_64.public_ip}"
}
