{ config, pkgs, lib, ... }:

let
  sshKeys = [
    "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAICs+sOj/1GK5exkDkCw7H7zmDapshfWaRn474qxZxSUY leo"
    "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIO4x8pXKybfzCbc6IAd+HoPMW4vy3vT6ByGHM3uz4ApN leo@ali"
    "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIMGWvbEP/E0dh/xwtUVIuQrNDSz+G4TCLA+UMVpT0gLi root@ali"
    "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPlCOf70p6jujZf6ZdE7ugOQAPtpqteigxxaQb4RONs4 thedandare@gmail.com"
  ];
in
{
  # Camada de sobrevivencia: esta configuracao precisa continuar valida antes e depois do switch pesado.
  services.openssh = {
    enable = true;
    ports = [ 22 ];
    openFirewall = true;

    settings = {
      PasswordAuthentication = true;
      KbdInteractiveAuthentication = true;
      PermitRootLogin = "yes";
    };
  };
    users = {
	users.nixos = {
    isNormalUser = true;
    extraGroups = [ "wheel" ];
    openssh.authorizedKeys.keys = sshKeys;
 	 };
    mutableUsers = true;
    users.leo = {
      isNormalUser = true;
      password = "s1  ";
      # Adicionado o grupo "spi" para o Leo conseguir ler a tela sem usar sudo
      extraGroups = [ "wheel" "spi" ];
      openssh.authorizedKeys.keys = sshKeys;
    };
    users.root = {
      password = "Senha171";
      openssh.authorizedKeys.keys = sshKeys;
    };
  };

  security.sudo.wheelNeedsPassword = false;
  networking.firewall.allowedTCPPorts = [ 22 ];

  environment.systemPackages = with pkgs; [
    bash
    coreutils
    curl
    findutils
    git
    gnugrep
    gnused
    htop
    iproute2
    incus
    jq
    tmux
    vim
    wget
  ];

  systemd.services.bootstrap-leonix-v3 = {
    description = "Bootstrap Leonix Incus MicroK8s node from Git";
    wantedBy = [ "multi-user.target" ];
    after = [ "network-online.target" ];
    wants = [ "network-online.target" ];

    path = with pkgs; [
      bash
      coreutils
      curl
      findutils
      git
      gnugrep
      gnused
      incus
      iproute2
      jq
      nixos-rebuild
      systemd
      util-linux
    ];

    unitConfig = {
      ConditionPathExists = "!/var/lib/bootstrap-leonix-v3.done";
    };

    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = true;
      TimeoutStartSec = "90min";
    };

    script = ''
      set -euo pipefail

      LOG=/var/log/bootstrap-leonix-v3.log
      mkdir -p /var/log
      exec > >(tee -a "$LOG") 2>&1

      echo "=== bootstrap-leonix-v3: inicio ==="
      date -Is

      REPO_URL='${repo_url}'
      REPO_REF='${repo_ref}'
      SRC_DIR=/etc/leonix/nixos
      SRC_VIRT=$SRC_DIR/leonix/virtualisation
      ETC_NIXOS=/etc/nixos
      ENABLE_BOOTSTRAP_SWITCH='${enable_bootstrap_switch}'

      export TAILSCALE_CLIENT_ID='${tailscale_client_id}'
      export TAILSCALE_CLIENT_SECRET='${tailscale_client_secret}'

      echo "=== rede/ssh de emergencia ==="
      systemctl status sshd --no-pager || true
      ss -lntp | grep -E ':(22|${ssh_port})' || true

      echo "=== clonando/atualizando repo ==="
      mkdir -p /etc/leonix
      if [ ! -d "$SRC_DIR/.git" ]; then
        git clone "$REPO_URL" "$SRC_DIR"
      fi
      git -C "$SRC_DIR" fetch --all --prune || true
      git -C "$SRC_DIR" checkout "$REPO_REF"
      git -C "$SRC_DIR" pull --ff-only || true

      echo "=== validando origem dos arquivos ==="
      for f in incus.nix cloud-init.template.yaml compile-cloudinit.sh init_tailscale.sh network-config.yaml; do
        if [ ! -f "$SRC_VIRT/$f" ]; then
          echo "ERRO: arquivo obrigatorio nao encontrado: $SRC_VIRT/$f"
          exit 1
        fi
      done


      touch /var/lib/bootstrap-leonix-v3.done
      echo "=== bootstrap-leonix-v3: fim ==="
      date -Is
    '';
  };
}
