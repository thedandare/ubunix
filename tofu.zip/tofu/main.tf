terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

locals {
  # Junta chaves publicas lidas de arquivos locais com chaves literais opcionais.
  ssh_public_keys = compact(concat(
    [for p in var.ssh_public_key_files : try(trimspace(file(p)), "")],
    var.extra_ssh_public_keys
  ))

  # Converte lista Terraform em lista Nix.
  ssh_public_keys_nix = join("\n    ", [
    for key in local.ssh_public_keys : "\"${key}\""
  ])
}

data "aws_ami" "nixos_x86_64" {
  owners      = ["427812963091"]
  most_recent = true

  filter {
    name   = "name"
    values = [var.nixos_ami_name_filter]
  }

  filter {
    name   = "architecture"
    values = ["x86_64"]
  }
}

resource "aws_security_group" "nixos" {
  name        = "${var.name}-sg"
  description = "NixOS bootstrap SSH ports"

  # Porta 22 temporaria para bootstrap e debug.
  # Remova quando a 2409 estiver validada em todos os hosts.
  ingress {
    description = "SSH default bootstrap"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = var.ssh_cidr_blocks
  }

  ingress {
    description = "SSH custom port"
    from_port   = var.ssh_port
    to_port     = var.ssh_port
    protocol    = "tcp"
    cidr_blocks = var.ssh_cidr_blocks
  }

  egress {
    description = "Allow outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.name}-sg"
  }
}

resource "aws_instance" "nixos_x86_64" {
  ami                         = data.aws_ami.nixos_x86_64.id
  instance_type               = var.instance_type
  associate_public_ip_address = true
  vpc_security_group_ids      = [aws_security_group.nixos.id]

  # Em bootstrap, mudar user_data deve recriar para reaplicar limpo.
  user_data_replace_on_change = true

  user_data = templatefile("${path.module}/nix/user-data.nix.tftpl", {
    ssh_port                = var.ssh_port
    ssh_public_keys_nix     = local.ssh_public_keys_nix
    repo_url                = var.repo_url
    repo_ref                = var.repo_ref
    tailscale_client_id     = var.tailscale_client_id
    tailscale_client_secret = var.tailscale_client_secret
    enable_bootstrap_switch = var.enable_bootstrap_switch
  })

  root_block_device {
    volume_size = var.root_volume_size
    volume_type = "gp3"
  }

  tags = {
    Name = var.name
  }
}
